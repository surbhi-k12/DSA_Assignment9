package in.ineuron;

public class DSA_4Pow {

	    public static int myPow(int x, int n) {
	        
	        if(n < 0){
	            n = -n;
	            x = 1 / x;
	        }
	        
	        int pow = 1;
	        
	        while(n != 0){
	            if((n & 1) != 0){
	                pow *= x;
	            } 
	                
	            x *= x;
	            n >>>= 1;
	            
	        }
	        
	        return pow;
	    }
	    
	    public static void main(String[] args) {
			int ans;
	    	int x= 5;
	    	int n=2;
	    	ans=myPow(x,n);
	    	System.out.println(ans);
		}
	}

