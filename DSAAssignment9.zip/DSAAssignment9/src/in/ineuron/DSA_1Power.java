package in.ineuron;

public class DSA_1Power {

	    public static boolean isPowerOfTwo(int n) {
	        if(n == 1){
	            return true;
	        }
	        else if(n == 0){
	            return false;
	        }
	        else if(n%2 != 0){
	            return false;
	        }
	        else{
	            return isPowerOfTwo(n/2);
	        }
	    }
	    
	    public static void main(String[] args) {
			int a=16;
			boolean ans;
			ans=isPowerOfTwo(a);
			System.out.println(ans);
		}
	    
	}


